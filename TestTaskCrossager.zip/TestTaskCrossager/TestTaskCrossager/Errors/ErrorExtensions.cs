﻿using Microsoft.AspNetCore.Mvc;
using TestTaskCrossager.Exceptions;
using TestTaskCrossager.Helpers;

namespace TestTaskCrossager.Errors
{
    public static class ErrorExtensions
    {
        public static ActionResult CreateErrorResult(this ControllerBase controller, Error error)
        {
            return error.Code switch
            {
                ErrorCode.ServerError => controller.CreateServerError(error),

                ErrorCode.GroupNotFound => controller.NotFound(
                        CreateValidationError(controller, StatusCodes.Status404NotFound, error.Code)),
                
                ErrorCode.GroupInvalidStatus => controller.Conflict(
                        CreateValidationError(controller, StatusCodes.Status409Conflict, error.Code)),

                _ => controller.BadRequest(
                        CreateValidationError(controller,StatusCodes.Status400BadRequest, error.Code))
            };
        }

        private static ObjectResult CreateValidationError(this ControllerBase controller, int statusCode, ErrorCode errorCode)
        {
            var problem = new ProblemDetails
            {
                Title = errorCode.ToString(),
                Detail = errorCode.GetDescription(),
                Status = statusCode,
                Type = "https://httpstatuses.com/400",
                Instance = controller.HttpContext.Request.Path
            };

            return new ObjectResult(problem);
        }

        private static ObjectResult CreateServerError(this ControllerBase controller, Error error)
        {
            var problem = new ProblemDetails
            {
                Title = "Internal Server Error",
                Detail = error.Message,
                Status = StatusCodes.Status500InternalServerError,
                Type = "https://httpstatuses.com/500",
                Instance = controller.HttpContext.Request.Path
            };

            problem.Extensions["errorCode"] = error.Code;

            return new ObjectResult(problem);
        }
    }
}
