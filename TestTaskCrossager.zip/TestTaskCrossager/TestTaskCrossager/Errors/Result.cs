﻿using TestTaskCrossager.Exceptions;

namespace TestTaskCrossager.Errors
{
    public class Result
    {
        public bool IsSuccess { get; init; }

        public Error? Error { get; init; }

        public static Result Success() =>
            new()
            {
                IsSuccess = true
            };

        public static Result Failure(ErrorCode code, string message = "") =>
            new()
            {
                IsSuccess = false,
                Error = new Error
                {
                    Code = code,
                    Message = message
                }
            };
    }


    public sealed class Result<T> : Result
    {

        public T? Value { get; init; }

        public static Result<T> Success(T value) =>
            new()
            {
                IsSuccess = true,
                Value = value
            };

        public static new Result<T> Failure(ErrorCode code, string message = "") =>
            new()
            {
                IsSuccess = false,
                Error = new Error
                { 
                    Code = code,
                    Message = message
                }
            };
    }

    public sealed class Error
    {
        public ErrorCode Code { get; init; }

        public string? Message { get; init; }
    }
}
