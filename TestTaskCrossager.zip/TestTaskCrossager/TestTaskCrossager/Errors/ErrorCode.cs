﻿using System.ComponentModel;

namespace TestTaskCrossager.Exceptions
{
    public enum ErrorCode
    {
        None = 0,

        [Description("Internal Server Error.")]
        ServerError,

        [Description("Invalid group specified.")]
        GroupNotFound,

        [Description("Group with invalid status specified.")]
        GroupInvalidStatus,
        
        [Description("Invalid group size.")]
        GroupInvalidSize,
    }
}
