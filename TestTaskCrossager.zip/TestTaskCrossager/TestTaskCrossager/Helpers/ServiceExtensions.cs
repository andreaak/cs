﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Polly;
using Polly.Retry;
using TestTaskCrossager.Errors;

namespace TestTaskCrossager.Helpers
{
    public static class ServiceExtensions
    {
        public static ResiliencePipeline<Result<T>> CreateDeadlockRetryPipeline<T>(this DbContext dbContext, ILogger? logger = default)
        {
            return new ResiliencePipelineBuilder<Result<T>>()
                .AddRetry(new RetryStrategyOptions<Result<T>>
                {
                    ShouldHandle = args => args.Outcome.Exception is SqlException { Number: 1205 }
                        ? PredicateResult.True()
                        : PredicateResult.False(),

                    MaxRetryAttempts = 3,
                    Delay = TimeSpan.FromMilliseconds(100),
                    BackoffType = DelayBackoffType.Exponential,
                    UseJitter = true,

                    OnRetry = args =>
                    {
                        dbContext.ChangeTracker.Clear();

                        logger?.LogWarning(args.Outcome.Exception, "SQL Server deadlock detected. Retry attempt {AttemptNumber}.", args.AttemptNumber + 1);

                        return default;
                    }
                })
                .Build();
        }
    }
}
