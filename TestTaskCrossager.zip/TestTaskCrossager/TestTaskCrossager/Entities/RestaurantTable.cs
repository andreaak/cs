﻿namespace TestTaskCrossager.Entities
{
    public sealed class RestaurantTable
    {
        public int Id { get; set; }

        public int Number { get; set; }

        public int Capacity { get; set; }

        public ICollection<GuestGroup> GuestGroups { get; set; } =  new List<GuestGroup>();
    }
}
