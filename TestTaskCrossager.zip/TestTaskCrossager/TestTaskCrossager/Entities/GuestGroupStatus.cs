﻿namespace TestTaskCrossager.Entities
{
    public enum GuestGroupStatus
    {
        Waiting = 1,

        Seated = 2,

        Completed = 3,

        Left = 4
    }
}
