﻿namespace TestTaskCrossager.Entities
{
    public sealed class GuestGroup
    {
        public int Id { get; set; }

        public int Size { get; set; }

        public GuestGroupStatus Status { get; set; }

        public DateTime ArrivedAt { get; set; }

        public int? TableId { get; set; }

        public RestaurantTable? Table { get; set; }
    }
}
