﻿using TestTaskCrossager.Api.RequestsResponses;
using TestTaskCrossager.Errors;

namespace TestTaskCrossager.Services
{
    public interface IGuestGroupService
    {
        Task<Result<CreateGuestGroupResponse>> CreateAsync(int size, CancellationToken cancellationToken);
        Task<Result> LeaveAsync(int groupId, CancellationToken cancellationToken);
        Task<Result<CompleteVisitResponse>> CompleteAsync(int groupId,  CancellationToken cancellationToken);
    }
}
