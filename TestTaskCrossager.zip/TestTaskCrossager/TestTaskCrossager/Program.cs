using Microsoft.EntityFrameworkCore;
using System.Reflection;
using TestTaskCrossager.Data;
using TestTaskCrossager.Repositories;
using TestTaskCrossager.Services;

namespace TestTaskCrossager
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddControllers()
                            .AddJsonOptions(options =>
                            {
                                options.JsonSerializerOptions.DefaultIgnoreCondition =
                                    System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
                            });


            builder.Services.AddDbContext<RestaurantDbContext>(options =>
            {
                options.UseSqlServer(builder.Configuration.GetConnectionString("RestaurantDatabase"));

                if (builder.Environment.IsDevelopment())
                {
                    options.EnableDetailedErrors();
                    options.EnableSensitiveDataLogging();
                }
            });

            builder.Services.AddScoped<IGuestGroupService, GuestGroupService>();
            builder.Services.AddSingleton(TimeProvider.System);

            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen(options =>
            {
                string xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                string xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);

                options.IncludeXmlComments(xmlPath);
            });


            var app = builder.Build();

            await app.EnsureDatabaseCreatedAsync();

            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();
            app.MapGet("/", () => Results.Redirect("/swagger"));

            app.Run();
        }
    }
}
