﻿using Microsoft.EntityFrameworkCore;
using TestTaskCrossager.Entities;
using TestTaskCrossager.Repositories;

namespace TestTaskCrossager.Data
{
    public static class DatabaseInitializer
    {
        public static async Task EnsureDatabaseCreatedAsync(this WebApplication app)
        {
            await using AsyncServiceScope scope = app.Services.CreateAsyncScope();

            var context = scope.ServiceProvider
                    .GetRequiredService<RestaurantDbContext>();

            var logger = scope.ServiceProvider
                    .GetRequiredService<ILogger<RestaurantDbContext>>();

            try
            {
                bool created = await context.Database.EnsureCreatedAsync();

                if (created)
                {
                    logger.LogInformation(
                        "Database '{Database}' was created successfully.",
                        context.Database.GetDbConnection().Database);
                }
                else
                {
                    logger.LogInformation(
                        "Database '{Database}' already exists.",
                        context.Database.GetDbConnection().Database);
                }

                await SeedTablesAsync(context, logger);
            }
            catch (Exception exception)
            {
                logger.LogCritical(exception, "Failed to create database.");

                throw;
            }
        }

        private static async Task SeedTablesAsync(
        RestaurantDbContext context,
        ILogger logger)
        {
            bool tablesExist = await context.Tables.AnyAsync();

            if (tablesExist)
            {
                logger.LogInformation("Restaurant tables already exist. Seeding skipped.");
                return;
            }

            var tables = new List<RestaurantTable>
            {
                new()
                {
                    Number = 1,
                    Capacity = 2
                },
                new()
                {
                    Number = 2,
                    Capacity = 2
                },
                new()
                {
                    Number = 3,
                    Capacity = 3
                },
                new()
                {
                    Number = 4,
                    Capacity = 3
                },
                new()
                {
                    Number = 5,
                    Capacity = 4
                },
                new()
                {
                    Number = 6,
                    Capacity = 4
                },
                new()
                {
                    Number = 7,
                    Capacity = 5
                },
                new()
                {
                    Number = 8,
                    Capacity = 5
                },
                new()
                {
                    Number = 9,
                    Capacity = 6
                },
                new()
                {
                    Number = 10,
                    Capacity = 6
                }
            };

            await context.Tables.AddRangeAsync(tables);

            await context.SaveChangesAsync();

            logger.LogInformation("{TableCount} restaurant tables were added.", tables.Count);
        }
    }
}
