﻿using Microsoft.EntityFrameworkCore;
using TestTaskCrossager.Entities;

namespace TestTaskCrossager.Repositories
{
    public sealed class RestaurantDbContext : DbContext
    {
        public RestaurantDbContext(
            DbContextOptions<RestaurantDbContext> options)
            : base(options)
        {
        }

        public DbSet<GuestGroup> GuestGroups => Set<GuestGroup>();

        public DbSet<RestaurantTable> Tables => Set<RestaurantTable>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            ConfigureGuestGroup(modelBuilder);

            ConfigureRestaurantTable(modelBuilder);

            base.OnModelCreating(modelBuilder);
        }

        private static void ConfigureGuestGroup(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<GuestGroup>(entity =>
            {
                entity.ToTable("GuestGroups");

                entity.HasKey(group => group.Id);

                entity.Property(group => group.Id)
                    .ValueGeneratedOnAdd();

                entity.Property(group => group.Size)
                    .IsRequired();

                entity.Property(group => group.Status)
                    .HasConversion<string>()
                    .HasMaxLength(20)
                    .IsRequired();

                entity.Property(group => group.ArrivedAt)
                    .IsRequired();

                entity.HasOne(group => group.Table)
                    .WithMany(table => table.GuestGroups)
                    .HasForeignKey(group => group.TableId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasIndex(group => new
                {
                    group.Status,
                    group.Size
                });

                entity.HasIndex(group => new
                {
                    group.Status,
                    group.ArrivedAt,
                    group.Id
                });

                entity.ToTable(table =>
                {
                    table.HasCheckConstraint(
                        "CK_GuestGroup_Size",
                        "[Size] BETWEEN 1 AND 6");
                });
            });
        }

        private static void ConfigureRestaurantTable(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<RestaurantTable>(entity =>
            {
                entity.ToTable("RestaurantTables");

                entity.HasKey(table => table.Id);

                entity.Property(table => table.Id)
                    .ValueGeneratedOnAdd();

                entity.Property(table => table.Number)
                    .IsRequired();

                entity.Property(table => table.Capacity)
                    .IsRequired();

                entity.HasIndex(table => table.Number)
                    .IsUnique();

                entity.ToTable(table =>
                {
                    table.HasCheckConstraint(
                        "CK_RestaurantTable_Capacity",
                        "[Capacity] BETWEEN 2 AND 6");
                });
            });
        }
    }
}
