﻿namespace TestTaskCrossager.Api.RequestsResponses
{
    public sealed class CompleteVisitResponse
    {
        public IReadOnlyCollection<NewlySeatedGroup> NewlySeatedGroups { get; init; }

        public CompleteVisitResponse(IReadOnlyCollection<NewlySeatedGroup> newlySeatedGroups)
        {
            NewlySeatedGroups = newlySeatedGroups;
        }

    }

    public sealed class NewlySeatedGroup
    {
        public int GroupId { get; init; }

        public int TableNumber { get; init; }
    }
}
