﻿namespace TestTaskCrossager.Api.RequestsResponses
{

    public sealed class CreateGuestGroupResponse
    {
        public int GroupId { get; init; }
        public required string Status { get; init; }
        public int? TableNumber { get; init; }
    }
}
