﻿using TestTaskCrossager.Api.RequestsResponses;
using TestTaskCrossager.Entities;

namespace TestTaskCrossager.Api.Mappers
{
    public static class GuestGroupMapper
    {
        public static CreateGuestGroupResponse MapToCreateGuestGroup(
                GuestGroup group)
        {
            return new CreateGuestGroupResponse
            {
                GroupId = group.Id,
                Status = group.Status.ToString(),
                TableNumber = group.Table?.Number
            };
        }
        
        public static NewlySeatedGroup MapToNewlySeatedGroup(
                GuestGroup group)
        {
            return new NewlySeatedGroup
            {
                GroupId = group.Id,
                TableNumber = group.Table.Number
            };
        }
    }
}


