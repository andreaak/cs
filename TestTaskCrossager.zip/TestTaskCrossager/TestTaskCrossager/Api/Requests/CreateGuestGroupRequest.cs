﻿
using System.ComponentModel.DataAnnotations;

namespace TestTaskCrossager.Api.Requests
{
    public class CreateGuestGroupRequest
    {
        [Required]

        [Range(1, 6)]
        public int Size { get; set; }
    }
}
