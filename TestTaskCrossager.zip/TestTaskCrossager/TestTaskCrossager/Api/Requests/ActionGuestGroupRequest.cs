﻿
using System.ComponentModel.DataAnnotations;

namespace TestTaskCrossager.Api.Requests
{
    public class ActionGuestGroupRequest
    {
        [Required]

        [Range(1, int.MaxValue)]
        public int GroupId { get; set; }
    }
}
