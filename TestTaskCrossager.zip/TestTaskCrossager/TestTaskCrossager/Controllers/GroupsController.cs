﻿using Microsoft.AspNetCore.Mvc;
using TestTaskCrossager.Api.Requests;
using TestTaskCrossager.Api.RequestsResponses;
using TestTaskCrossager.Errors;
using TestTaskCrossager.Services;

namespace TestTaskCrossager.Controllers
{

    [ApiController]
    [Route("api/v1/groups")]
    [Produces("application/json")]
    public sealed class GroupsController : ControllerBase
    {
        private readonly IGuestGroupService _groupService;

        public GroupsController(IGuestGroupService groupService)
        {
            _groupService = groupService;
        }

        /// <summary>
        /// Registers a new guest group.
        /// </summary>
        /// <response code="201">The guest group was successfully created.</response>
        /// <response code="400">The request is invalid.</response>
        /// <response code="500">An unexpected server error occurred.</response>
        [HttpPost]
        [ProducesResponseType(typeof(CreateGuestGroupResponse),  StatusCodes.Status201Created)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<CreateGuestGroupResponse>> CreateGroup(CreateGuestGroupRequest request,
            CancellationToken cancellationToken)
        {
            var result = await _groupService.CreateAsync(request.Size, cancellationToken);

            if(result.Error is not null)
            {
                return this.CreateErrorResult(result.Error);
            }

            return StatusCode(StatusCodes.Status201Created, result.Value);
        }

        /// <summary>
        /// Removes a waiting guest group from the queue.
        /// </summary>
        /// <response code="200">The group was successfully removed from the waiting queue.</response>
        /// <response code="400">The request is invalid.</response>
        /// <response code="404">The specified group was not found.</response>
        /// <response code="409">The guest group cannot leave because its current status does not allow this operation.</response>
        /// <response code="500">An unexpected server error occurred.</response>
        [HttpPost("leave")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult> Leave(ActionGuestGroupRequest request, CancellationToken cancellationToken)
        {

            var result = await _groupService.LeaveAsync(request.GroupId, cancellationToken);

            if (result.Error is not null)
            {
                return this.CreateErrorResult(result.Error);
            }

            return Ok();
        }

        /// <summary>
        /// Marks the visit of a seated guest group as completed.
        /// </summary>
        /// <response code="200">The visit was successfully completed.</response>
        /// <response code="400">The request is invalid.</response>
        /// <response code="404">The specified group was not found.</response>
        /// <response code="409">The guest group cannot complete the visit because its current status does not allow this operation.</response>
        /// <response code="500">An unexpected server error occurred.</response>
        [HttpPost("complete")]
        [ProducesResponseType(typeof(CompleteVisitResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<CompleteVisitResponse>> Complete(ActionGuestGroupRequest request, CancellationToken cancellationToken)
        {
            var result = await _groupService.CompleteAsync(request.GroupId, cancellationToken);

            if (result.Error is not null)
            {
                return this.CreateErrorResult(result.Error);
            }

            return Ok(result.Value);
        }
    }
}
